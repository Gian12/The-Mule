from launch import LaunchDescription

def generate_launch_description():
    return LaunchDescription([])

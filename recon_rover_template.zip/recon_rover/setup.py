from setuptools import setup

package_name = 'recon_rover'

setup(
    name=package_name,
    version='0.0.0',
    packages=[package_name],
    data_files=[
        ('share/' + package_name, ['package.xml']),
        ('share/' + package_name + '/launch', ['launch/bringup.launch.py']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='Gian',
    maintainer_email='gian@example.com',
    description='Recon Rover package for Jetson',
    license='MIT',
    entry_points={
        'console_scripts': [
            'mdds30_driver = recon_rover.mdds30_driver:main',
            'joy_mux = recon_rover.joy_mux:main',
        ],
    },
)
